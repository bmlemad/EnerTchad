# EnerTchad S.A. — Fiche de presse

*Document de référence presse. Société en constitution : toutes les capacités et tous les chiffres d’activité sont des objectifs datés, non des actifs en exploitation.*

## Identité
- **Raison sociale** : EnerTchad S.A.
- **Forme** : société anonyme de droit OHADA (AUSCGIE)
- **Statut** : société en constitution
- **Objet** : société pétrolière intégrée — de l’exploration-production à la distribution
- **Slogan** : Unité · Innovation · Durabilité
- **Signature** : « De la roche-mère à la pompe. »

## Coordonnées
- **Siège** : Radisson Blu, Block D, Bureau 23, Sabangali, N’Djamena, Tchad
- **RCCM** : N’DJ/RC/2026-A-0001
- **Domaine** : enertchad.td
- **Contact presse** : contact@enertchad.td · +235 99 29 86 96

## Capital (trajectoire visée)
- Capital fondateur : 10 000 000 FCFA
- Levée court terme visée : ~1 Md FCFA
- Horizon long terme visé : ~20 Md FCFA
- Partenaire investissement : GCIC

## Organisation
EnerTchad est une **société unique** (pas un groupe, pas de filiales), organisée en **huit pôles d’activité internes** : quatre forment la chaîne pétrolière et chimique (Amont, Intermédiaire, Aval, Pétrochimie) et quatre la soutiennent (GreenTech, TchadiTech, Tchaditude, EnerConseils).

## Palette officielle
Le logo officiel est un trèfle à quatre pétales dans un anneau d’or, sur fond crème.
- **Or du logo (pétale haut, dégradé)** : #DBAE4A → #C2922E
- **Bleu (pétale gauche)** : #1E6EC2
- **Vert (pétale droit)** : #218A2C
- **Crème doré (pétale bas)** : #E8CD7F
- **Crème (fond du logo)** : #F3EAD1
- **Marine (fonds sombres du site)** : #070D18 · #0B1422
- **Ors d’interface (site)** : #D9A84F · #E8C36A · #F0CE82

## Engagements
Contenu local visé (priorité aux compétences et emplois tchadiens), démarche HSE-Q, arc E-S-G et conformité OHADA/IFRS, normes ISO et standards ITIE visés.

---
*EnerTchad S.A. · N’Djamena · Mise à jour : juillet 2026.*
